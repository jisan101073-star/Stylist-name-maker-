Stylish Name Maker Bot - modified from the uploaded Stylish-Text project

Files:
- bot.py
- config.py
- requirements.txt
- runtime.txt
- plugins/commands.py
- plugins/fonts.py (original uploaded font engine)

Environment variables:
BOT_TOKEN
API_ID
API_HASH
OWNER_ID

Current build:
- Screenshot-style main menu
- Make My Name flow
- 4 category sections
- 10 styles per page
- Next/Previous pagination
- Selected design screen
- Copy-style text message
- Edit Components flow
- Main Menu / Back / New Name navigation

Note:
The uploaded fonts.py contains 39 font functions, so this first build uses those
39 transformations rather than claiming 145+ styles. BIO and Bulk Names are
left as placeholders for the next module.
