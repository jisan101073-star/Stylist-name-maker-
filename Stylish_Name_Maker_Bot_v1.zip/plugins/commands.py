from config import Config
from .fonts import Fonts
from pyrogram import filters
from pyrogram import Client as MoTech
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup


# ---------------------------------------------------------
# Stylish Name Maker Bot
# State is kept in memory for the running process.
# ---------------------------------------------------------

USER_STATE = {}
USER_NAME = {}


def main_menu():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✏️ Make My Name", callback_data="menu_name"),
            InlineKeyboardButton("📝 BIO", callback_data="menu_bio"),
        ],
        [
            InlineKeyboardButton("🚀 Bulk Names", callback_data="menu_bulk"),
            InlineKeyboardButton("❓ Help", callback_data="menu_help"),
        ],
    ])


def category_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("👑 PREMIUM DESIGN", callback_data="cat_premium")],
        [InlineKeyboardButton("✨ Aesthetic Art Styles", callback_data="cat_aesthetic")],
        [InlineKeyboardButton("🎬 Live Design", callback_data="cat_live")],
        [InlineKeyboardButton("🇮🇳 Hindi Live Design", callback_data="cat_hindi")],
        [
            InlineKeyboardButton("✏️ New Name", callback_data="menu_name"),
            InlineKeyboardButton("🏠 Main Menu", callback_data="home"),
        ],
    ])


# Existing Fonts class from the uploaded project.
STYLE_MAP = {
    "typewriter": ("𝚃𝚢𝚙𝚎𝚠𝚛𝚒𝚝𝚎𝚛", Fonts.typewriter),
    "outline": ("𝕆𝕦𝕥𝕝𝕚𝕟𝕖", Fonts.outline),
    "serief": ("𝐒𝐞𝐫𝐢𝐟", Fonts.serief),
    "bold_cool": ("𝑺𝒆𝒓𝒊𝒇", Fonts.bold_cool),
    "cool": ("𝑆𝑒𝑟𝑖𝑓", Fonts.cool),
    "smallcap": ("Sᴍᴀʟʟ Cᴀᴘs", Fonts.smallcap),
    "script": ("𝓈𝒸𝓇𝒾𝓅𝓉", Fonts.script),
    "bold_script": ("𝓼𝓬𝓻𝓲𝓹𝓽", Fonts.bold_script),
    "tiny": ("ᵗⁱⁿʸ", Fonts.tiny),
    "comic": ("ᑕOᗰIᑕ", Fonts.comic),
    "san": ("𝗦𝗮𝗻𝘀", Fonts.san),
    "slant_san": ("𝙎𝙖𝙣𝙨", Fonts.slant_san),
    "slant": ("𝘚𝘢𝘯𝘴", Fonts.slant),
    "sim": ("𝖲𝖺𝗇𝗌", Fonts.sim),
    "circles": ("Ⓒ︎Ⓘ︎Ⓡ︎Ⓒ︎Ⓛ︎Ⓔ︎Ⓢ︎", Fonts.circles),
    "dark_circle": ("🅒︎🅘︎🅡︎🅒︎🅛︎🅔︎🅢︎", Fonts.dark_circle),
    "gothic": ("𝔊𝔬𝔱𝔥𝔦𝔠", Fonts.gothic),
    "bold_gothic": ("𝕲𝖔𝖙𝖍𝖎𝖈", Fonts.bold_gothic),
    "cloud": ("C͜͡l͜͡o͜͡u͜͡d͜͡s͜͡", Fonts.cloud),
    "happy": ("H̆̈ă̈p̆̈p̆̈y̆̈", Fonts.happy),
    "sad": ("S̑̈ȃ̈d̑̈", Fonts.sad),
    "special": ("🇸 🇵 🇪 🇨 🇮 🇦 🇱 ", Fonts.special),
    "square": ("🅂🅀🅄🄰🅁🄴🅂", Fonts.square),
    "dark_square": ("🆂︎🆀︎🆄︎🅰︎🆁︎🅴︎🅂︎", Fonts.dark_square),
    "andalucia": ("ꪖꪀᦔꪖꪶꪊᥴ𝓲ꪖ", Fonts.andalucia),
    "manga": ("爪卂几ᘜ卂", Fonts.manga),
    "stinky": ("S̾t̾i̾n̾k̾y̾", Fonts.stinky),
    "bubbles": ("B̥ͦu̥ͦb̥ͦb̥ͦl̥ͦe̥ͦs̥ͦ", Fonts.bubbles),
    "underline": ("U͟n͟d͟e͟r͟l͟i͟n͟e͟", Fonts.underline),
    "ladybug": ("꒒ꍏꀷꌩꌃꀎꁅ", Fonts.ladybug),
    "rays": ("R҉a҉y҉s҉", Fonts.rays),
    "birds": ("B҈i҈r҈d҈s҈", Fonts.birds),
    "slash": ("S̸l̸a̸s̸h̸", Fonts.slash),
    "stop": ("s⃠t⃠o⃠p⃠", Fonts.stop),
    "skyline": ("S̺͆k̺͆y̺͆l̺͆i̺͆n̺͆e̺͆", Fonts.skyline),
    "arrows": ("A͎r͎r͎o͎w͎s͎", Fonts.arrows),
    "rvnes": ("ዪሀክቿነ", Fonts.rvnes),
    "strike": ("S̶t̶r̶i̶k̶e̶", Fonts.strike),
    "frozen": ("F༙r༙o༙z༙e༙n༙", Fonts.frozen),
}

# The uploaded font engine currently contains 39 styles.
# We divide those styles into visual sections for the Name Maker UI.
CATEGORIES = {
    "premium": [
        "serief", "bold_cool", "cool", "san", "slant_san",
        "slant", "sim", "gothic", "bold_gothic", "square",
        "dark_square", "dark_circle",
    ],
    "aesthetic": [
        "script", "bold_script", "outline", "circles", "cloud",
        "happy", "sad", "andalucia", "manga", "ladybug",
        "special", "rvnes",
    ],
    "live": [
        "typewriter", "tiny", "comic", "stinky", "bubbles",
        "underline", "rays", "birds", "slash", "stop",
        "skyline", "arrows", "strike", "frozen",
    ],
    # These are the same Unicode font transformations, presented
    # as a separate section. The current Fonts.py does not contain
    # dedicated Hindi glyph maps.
    "hindi": [
        "bold_cool", "script", "bold_script", "gothic", "bold_gothic",
        "comic", "san", "slant_san", "circles", "dark_circle",
    ],
}

CATEGORY_TITLES = {
    "premium": "👑 PREMIUM DESIGN",
    "aesthetic": "✨ Aesthetic Art Styles",
    "live": "🎬 Live Design",
    "hindi": "🇮🇳 Hindi Live Design",
}


def page_keyboard(category, page=0):
    styles = CATEGORIES[category]
    per_page = 10
    total_pages = max(1, (len(styles) + per_page - 1) // per_page)
    page = max(0, min(page, total_pages - 1))

    chunk = styles[page * per_page:(page + 1) * per_page]
    rows = []

    # Screenshot-like numbered style buttons: 2 per row.
    for i in range(0, len(chunk), 2):
        row = []
        for style_id in chunk[i:i + 2]:
            label, _ = STYLE_MAP[style_id]
            row.append(
                InlineKeyboardButton(
                    f"{styles.index(style_id) + 1}. {label}",
                    callback_data=f"style|{category}|{page}|{style_id}",
                )
            )
        rows.append(row)

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton("⬅️ Previous", callback_data=f"page|{category}|{page - 1}"))
    nav.append(InlineKeyboardButton(f"{page + 1}/{total_pages}", callback_data="noop"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("Next ➡️", callback_data=f"page|{category}|{page + 1}"))
    rows.append(nav)

    rows.append([
        InlineKeyboardButton("⬅️ Back", callback_data="categories"),
        InlineKeyboardButton("✏️ New Name", callback_data="menu_name"),
        InlineKeyboardButton("🏠 Main Menu", callback_data="home"),
    ])

    return InlineKeyboardMarkup(rows)


def selected_keyboard(category, page, style_id):
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📋 Copy Code", callback_data=f"copy|{category}|{page}|{style_id}"),
            InlineKeyboardButton("📝 Edit Components", callback_data=f"edit|{category}|{page}|{style_id}"),
        ],
        [
            InlineKeyboardButton("⬅️ Back", callback_data=f"page|{category}|{page}"),
            InlineKeyboardButton("🏠 Main Menu", callback_data="home"),
        ],
    ])


def welcome_text(user):
    return f"""✨ **Welcome to Stylish Name Maker Bot!** ✨

👑 **Premium & Aesthetic Name Studio**

───────────────

🎨 **Stylish Unicode Name Maker**
📝 **Aesthetic & Bio-ready Designs**
⚡ **39+ Built-in Font Styles**

───────────────

👇 **Niche diye gaye buttons se option select karein:** 👇"""


async def send_main_menu(c, m):
    await m.reply_text(welcome_text(m.from_user), reply_markup=main_menu(), quote=True)


@MoTech.on_message(filters.command("start") & filters.private)
async def start(c, m):
    USER_STATE.pop(m.from_user.id, None)
    await send_main_menu(c, m)


@MoTech.on_message(filters.command("help") & filters.private)
async def help_command(c, m):
    text = """❓ **How To Use**

1️⃣ Tap **✏️ Make My Name**
2️⃣ Send your name
3️⃣ Choose a design category
4️⃣ Select any style
5️⃣ Copy the generated name

💡 You can create another name anytime with **✏️ New Name**."""
    await m.reply_text(text, reply_markup=InlineKeyboardMarkup([
        [InlineKeyboardButton("✏️ Make My Name", callback_data="menu_name")],
        [InlineKeyboardButton("🏠 Main Menu", callback_data="home")],
    ]))


@MoTech.on_message(filters.private & filters.text & ~filters.command(["start", "help"]))
async def receive_name(c, m):
    uid = m.from_user.id

    # Accept text for a new name or for the Edit Components flow.
    state = USER_STATE.get(uid, "")
    if state not in ("waiting_name",) and not state.startswith("editing:"):
        return

    name = m.text.strip()
    if not name:
        await m.reply_text("❌ Please send a valid name.")
        return

    if len(name) > 100:
        await m.reply_text("❌ Name is too long. Please keep it within 100 characters.")
        return

    USER_NAME[uid] = name

    # If this is an edit request, regenerate the previously selected style.
    if state.startswith("editing:"):
        _, category, page_s, style_id = state.split(":", 3)
        if style_id in STYLE_MAP and category in CATEGORIES:
            _, converter = STYLE_MAP[style_id]
            styled = converter(name)
            USER_STATE[uid] = f"selected:{category}:{page_s}:{style_id}"
            await m.reply_text(
                f"✨ **Updated Design:**\n\n`{styled}`\n\n"
                "Edit ya copy ke liye buttons use karein:",
                reply_markup=selected_keyboard(category, int(page_s), style_id),
                quote=True,
            )
            await m.reply_text(styled)
            return

    USER_STATE[uid] = "categories"
    await m.reply_text(
        f"""✅ **Name:** `{name}`

👇 **Kripya Niche Diye Gaye 4 Category Sections Me Se Select Karein:** 👇""",
        reply_markup=category_menu(),
        quote=True,
    )


@MoTech.on_callback_query()
async def callbacks(c, q):
    uid = q.from_user.id
    data = q.data or ""

    if data == "noop":
        await q.answer()
        return

    if data == "home":
        USER_STATE[uid] = "home"
        await q.answer()
        await q.message.edit_text(welcome_text(q.from_user), reply_markup=main_menu())
        return

    if data == "menu_name":
        USER_STATE[uid] = "waiting_name"
        await q.answer("Send me your name ✨")
        await q.message.edit_text(
            """✏️ **Make My Name**

Send me the name you want to style.

Example: `Jisan`""",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏠 Main Menu", callback_data="home")]
            ]),
        )
        return

    if data == "categories":
        if uid not in USER_NAME:
            USER_STATE[uid] = "waiting_name"
            await q.answer("Please send your name first.")
            await q.message.edit_text(
                "✏️ **Make My Name**\n\nSend me your name ✨",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🏠 Main Menu", callback_data="home")]
                ]),
            )
            return

        USER_STATE[uid] = "categories"
        await q.answer()
        await q.message.edit_text(
            f"✅ **Name:** `{USER_NAME[uid]}`\n\n"
            "👇 **Select a category:** 👇",
            reply_markup=category_menu(),
        )
        return

    if data == "menu_help":
        await q.answer()
        await q.message.edit_text(
            """❓ **Help**

✏️ **Make My Name** — create a stylish name
📝 **BIO** — coming in the next module
🚀 **Bulk Names** — coming in the next module

The current build uses the existing 39-style `fonts.py` engine.""",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✏️ Make My Name", callback_data="menu_name")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="home")],
            ]),
        )
        return

    if data in ("menu_bio", "menu_bulk"):
        await q.answer("This module is coming next 🚀", show_alert=True)
        return

    if data.startswith("cat_"):
        category = data[4:]
        if category not in CATEGORIES:
            await q.answer("Unknown category.", show_alert=True)
            return
        if uid not in USER_NAME:
            await q.answer("Please send a name first.", show_alert=True)
            return

        USER_STATE[uid] = f"category:{category}:0"
        await q.answer()
        styles = CATEGORIES[category]
        total_pages = max(1, (len(styles) + 9) // 10)
        await q.message.edit_text(
            f"✨ **{CATEGORY_TITLES[category]}**\n\n"
            f"👤 Name: `{USER_NAME[uid]}`\n"
            f"🎨 {len(styles)} available styles\n\n"
            "👇 **Click on any style below to view your design:**",
            reply_markup=page_keyboard(category, 0),
        )
        return

    if data.startswith("page|"):
        _, category, page_s = data.split("|", 2)
        page = int(page_s)
        if category not in CATEGORIES or uid not in USER_NAME:
            await q.answer("Please start again.", show_alert=True)
            return

        USER_STATE[uid] = f"category:{category}:{page}"
        await q.answer()
        await q.message.edit_text(
            f"✨ **{CATEGORY_TITLES[category]}**\n\n"
            f"👤 Name: `{USER_NAME[uid]}`\n\n"
            "👇 **Click on any style below to view your design:**",
            reply_markup=page_keyboard(category, page),
        )
        return

    if data.startswith("style|"):
        _, category, page_s, style_id = data.split("|", 3)
        page = int(page_s)

        if category not in CATEGORIES or style_id not in STYLE_MAP:
            await q.answer("Style not found.", show_alert=True)
            return

        name = USER_NAME.get(uid)
        if not name:
            await q.answer("Please enter your name first.", show_alert=True)
            return

        _, converter = STYLE_MAP[style_id]
        styled = converter(name)

        USER_STATE[uid] = f"selected:{category}:{page}:{style_id}"
        await q.answer()
        await q.message.edit_text(
            f"✨ **Aapka Selected Design:**\n\n"
            f"`{styled}`\n\n"
            "Edit ya copy ke liye buttons use karein:",
            reply_markup=selected_keyboard(category, page, style_id),
        )

        # Sending the styled text separately makes Telegram's native
        # long-press copy action easy to use.
        await q.message.reply_text(styled)
        return

    if data.startswith("copy|"):
        _, category, page_s, style_id = data.split("|", 3)
        name = USER_NAME.get(uid)
        if not name or style_id not in STYLE_MAP:
            await q.answer("Please start again.", show_alert=True)
            return

        _, converter = STYLE_MAP[style_id]
        styled = converter(name)
        await q.answer("Copied-style text sent below ✨")
        await q.message.reply_text(styled)
        return

    if data.startswith("edit|"):
        _, category, page_s, style_id = data.split("|", 3)
        USER_STATE[uid] = f"editing:{category}:{page_s}:{style_id}"
        await q.answer("Send the new name ✨")
        await q.message.edit_text(
            "📝 **Edit Components**\n\n"
            "Send the new name/text you want to use.\n\n"
            "Example: `Jisan`",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Back", callback_data=f"page|{category}|{page_s}")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="home")],
            ]),
        )
        return

    if data.startswith("styleedit|"):
        await q.answer()
        return

    await q.answer()
